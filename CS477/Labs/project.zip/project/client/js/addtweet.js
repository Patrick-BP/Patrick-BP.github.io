window.onload = function(){ 
    // const userid = sessionStorage.getItem('userID');
    // const username = sessionStorage.getItem('username');

      if(sessionStorage.getItem('accessToken')){
        document.getElementById('addtweetBtn').onclick = function(){
            
            addTweet(userid);
        };
           fetchTwites();
      }else{
          window.location='index.html';
      }
}
function addTweet(id){
    fetch('http://localhost:8888/tweets',{
        method:'POST',
        body:JSON.stringify({
            tweet: document.getElementById('tweet-body').value,
            user: id

        }),
        headers:{
            Authorization: `Bearer ${sessionStorage.getItem('accessToken')}`
        }
    })
}