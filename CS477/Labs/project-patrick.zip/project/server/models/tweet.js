const mongoose = require('mongoose');

const Tweet = require('./tweet');
const Follower = require('./followers');


const Schema = mongoose.Schema;

const tweetSchema = new Schema({
    tweet: String,
    user:[{type:Schema.Types.ObjectId, ref:'User'}]
});


// userSchema.methods.addToPost = async function (productId) {
//     const post = await Tweet.findById(picture);
//     if (post) {
//         const tweet = this.tweet;
//         const isExisting = tweet.items.findIndex(objInItems => new String(objInItems.picture).trim() === new String(product._id).trim());
//         if (isExisting >= 0) {
//             cart.items[isExisting].qty += 1;
//         } else {
//             cart.items.push({ productId: product._id, qty: 1 });
//         }
//         if (!cart.totalPrice) {
//             cart.totalPrice = 0;
//         }
//         cart.totalPrice += product.price;
//         return this.save();
//     }

// };


// userSchema.methods.removeFromPost = function (productId) {
//     const tweet = this.tweet;
//     const isExisting = tweet.items.findIndex(objInItems => new String(objInItems.picture).trim() === new String(picture).trim());
//     if (isExisting >= 0) {
//         tweet.items.splice(isExisting, 1);
//         return this.save();
//     }
// }




module.exports = mongoose.model('Tweet', tweetSchema);