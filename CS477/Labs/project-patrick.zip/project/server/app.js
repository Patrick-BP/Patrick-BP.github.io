const express = require('express');
const mongoose = require('mongoose');

const userRouter = require('./routes/userRouter');

const app = express();

app.use (express.json());
app.use('/users', userRouter); 
// app.use('/tweets', tweetRouter); // may be need to create this. 

mongoose.connect('mongodb://127.0.0.1:27017/social')
        .then(()=>{
            app.listen(3000, ()=> console.log('Listening to 3000...........'))
        });