const express = require('express');

const userController = require('../controllers/userController');

const router = express.Router();

router.get('/:id', userController.getTweetsById);
router.post('/', userController.save);
router.get('/:userId/follower/:followerId',userController.getFollower);

module.exports = router;