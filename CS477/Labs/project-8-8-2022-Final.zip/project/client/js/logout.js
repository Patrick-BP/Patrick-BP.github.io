
function logoutfunc(){
    // sessionStorage.removeItem('accessToken');
    sessionStorage.clear();
    window.location='index.html';
}